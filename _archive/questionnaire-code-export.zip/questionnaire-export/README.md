# Questionnaire Code Export

This archive contains all questionnaire-related code from the DRSS Marketing Agency OS project.

## 📦 Contents

### Components (`components/`)
All React components for the questionnaire UI:

- **`question-types/`** - Input components for different question types
  - `long-text-question.tsx` - Multi-line text input with character counter
  - `short-text-question.tsx` - Single-line text input
  - `multiple-choice-question.tsx` - Radio/checkbox selection
  - `file-upload-question.tsx` - Drag-and-drop file uploader
  - `question-wrapper.tsx` - Wrapper with question number, help button, etc.

- **`sections/`** - 8 questionnaire sections
  - `avatar-definition-section.tsx` - Section 1 (Q1-Q5)
  - `dream-outcome-section.tsx` - Section 2 (Q6-Q10)
  - `problems-obstacles-section.tsx` - Section 3 (Q11-Q15)
  - `solution-methodology-section.tsx` - Section 4 (Q16-Q19)
  - `brand-voice-section.tsx` - Section 5 (Q20-Q23, Q33)
  - `proof-transformation-section.tsx` - Section 6 (Q24-Q27, Q34)
  - `faith-integration-section.tsx` - Section 7 (Q28-Q30, conditional)
  - `business-metrics-section.tsx` - Section 8 (Q31-Q32)
  - `section-container.tsx` - Wrapper for section layout
  - `section-header.tsx` - Section title and progress

- **`navigation/`** - Navigation components
  - `progress-indicator.tsx` - Top progress bar with step dots
  - `step-footer.tsx` - Bottom navigation with Previous/Next/Save
  - `section-nav.tsx` - Sidebar navigation (legacy)

- **`help-system/`** - Contextual help system
  - `help-panel.tsx` - Slide-out help drawer
  - `help-content.tsx` - Help content display
  - `help-trigger.tsx` - Help button component

- **`review/`** - Review and submission
  - `questionnaire-review.tsx` - Final review page
  - `review-section-card.tsx` - Expandable section cards

### Logic (`lib/`)
Core questionnaire logic and state management:

- **`use-questionnaire-form.ts`** - Main React hook (438 lines)
  - Form state management
  - Auto-save (1 second debounce)
  - Save on navigation/unmount
  - Validation logic
  - Section navigation
  - Progress tracking

- **`types.ts`** - TypeScript interfaces
  - `QuestionnaireData` - Full form data structure
  - `UploadedFile` - File upload type
  - `FormStatus` - Save status type
  - Constants: `REQUIRED_QUESTIONS`, `OPTIONAL_QUESTIONS`, `EMPTY_QUESTIONNAIRE_DATA`

- **`validation-schemas.ts`** - Zod validation schemas
  - Individual schemas for all 32 questions
  - Minimum character requirements (20 chars for most)
  - Full questionnaire schema

- **`conditional-logic.ts`** - Question visibility logic
  - `shouldShowQuestion()` - Determines if Q29/Q30 should show based on Q28

- **`section-data.ts`** - Section metadata
  - Section titles, descriptions, question counts, time estimates

- **`help-guide-data.ts`** - Contextual help content
  - Help entries for each question
  - "Where to find", "How to extract", examples, tips

### Pages (`app/`)

- **`clients/onboarding/[id]/page.tsx`** - Main questionnaire page
  - Multi-step form (one section per screen)
  - Keyboard navigation (Cmd+Arrow keys, Esc)
  - URL state management
  - Integration with all components

- **`clients/profile/client-profile-page.tsx`** - Client profile
  - "Complete Questionnaire" / "Resume Questionnaire" button
  - Questionnaire status display
  - Entry point to questionnaire

- **`actions/questionnaire.ts`** - Server action
  - Saves completed questionnaire to Supabase
  - Handles file uploads to Supabase Storage
  - Updates client status

### Database (`supabase/`)

- **`migrations/add_questionnaire_tracking.sql`** - Database schema
  - Adds `questionnaire_status`, `questionnaire_progress`, `questionnaire_completed_at` to `clients` table
  - Creates indexes for performance

## 🔑 Key Features

### Auto-Save System
- **1 second debounce** after last keystroke
- Saves to `localStorage` with keys:
  - `questionnaire_draft_{clientId}` - Form data
  - `questionnaire_completed_{clientId}` - Completed questions
  - `questionnaire_current_step_{clientId}` - Current section
- **Save on navigation**: `beforeunload` event + component unmount

### Validation
- **Per-question validation** using Zod schemas
- **Section validation** before allowing navigation
- **Real-time error display** with character counts
- **Minimum requirements**: 20 chars for most questions, 10 for short answers

### Multi-Step Form
- **8 sections** displayed one at a time
- **Progress indicator** at top with clickable dots
- **Step footer** at bottom with Previous/Next/Save
- **Keyboard shortcuts**: Cmd+Arrow keys, Esc to save and exit

### File Uploads
- **Q33**: Brand assets (logos, style guides)
- **Q34**: Proof materials (testimonials, case studies)
- **Drag-and-drop** interface
- **5 files max**, 10MB per file
- Uploads to Supabase Storage

### Conditional Logic
- **Q28** controls visibility of Q29 and Q30
- Q29/Q30 only show if Q28 = "explicit" or "values_aligned"

## 🐛 Known Issues (As of Export)

### Critical Issues Identified:

1. **`markQuestionCompleted` called without validation**
   - Questions marked "complete" on every keystroke
   - No check if answer meets minimum requirements
   - **Location**: All section components (e.g., `faith-integration-section.tsx` lines 92, 112)

2. **`canGoNext()` doesn't validate content**
   - Only checks if questions are in `completedQuestions` Set
   - Doesn't call `validateQuestion()` to check actual content
   - **Location**: `use-questionnaire-form.ts` lines 287-289

3. **`validateSection` is misnamed**
   - Checks completion status, not validation
   - Should call `validateQuestion()` for each required question
   - **Location**: `use-questionnaire-form.ts` lines 255-278

4. **Section 7 marks questions complete on ANY change**
   - No conditional check before calling `markQuestionCompleted`
   - Empty or 1-character answers mark questions as "complete"
   - **Location**: `faith-integration-section.tsx` lines 92, 112

5. **Outdated UI text**
   - Says "auto-saved every 30 seconds" but it's now 1 second
   - **Location**: `page.tsx` line 186

### Recommended Fixes:

1. Update `validateSection` to call `validateQuestion()` for each required question
2. Add validation check before calling `markQuestionCompleted` in all sections
3. Separate "completion tracking" from "validation passing"
4. Update UI text to reflect 1-second auto-save

## 📊 Statistics

- **Total Files**: 38 TypeScript/TSX files + 1 SQL file
- **Total Lines**: ~5,000+ lines of code
- **Components**: 25+ React components
- **Questions**: 32 questions across 8 sections
- **Validation Schemas**: 32 Zod schemas

## 🔧 Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Validation**: Zod
- **Animation**: Framer Motion (help panel)
- **Database**: Supabase (PostgreSQL)
- **Storage**: Supabase Storage (file uploads)
- **State**: React hooks (custom `useQuestionnaireForm`)
- **Persistence**: localStorage (drafts), Supabase (final submission)

## 📝 Notes

- All components are client components (`'use client'`)
- Form data is auto-saved to localStorage every 1 second
- Final submission saves to Supabase `clients.intake_responses` (JSONB)
- File uploads go to Supabase Storage bucket `questionnaire-uploads`
- Progress tracking uses `questionnaire_status` enum: `not_started`, `in_progress`, `completed`

---

**Exported**: December 10, 2025
**Project**: DRSS Marketing Agency OS
**Feature**: Client Onboarding Questionnaire
